//
// Created by elisha on 12/15/18.
//

#include "Number.h"

Number::Number(double value) : value (value) {

}
double Number::evaluate() {
    return this->value;
}

Number::~Number() {

}

